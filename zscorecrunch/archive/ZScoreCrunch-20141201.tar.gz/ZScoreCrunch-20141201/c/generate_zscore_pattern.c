#include <stdio.h>

int main(int argc, char **argv) {
	int p1[4] = {-1, 0, 1, 0};
	int p2[4] = {1, 0, -1, 0};
	int p3[4] = {0, 1, 0, -1};
	int p4[4] = {0, -1, 0, 1};
	printf("idx\t\tp1\t\tp2\t\tp3\t\tp4\n");
	for(int i = 0; i < 20; i++) {
		printf("%d\t\t%d\t\t%d\t\t%d\t\t%d\n", i, p1[i%4], p2[i%4], p3[i%4], p4[i%4]);
	}
	return 0;
}
