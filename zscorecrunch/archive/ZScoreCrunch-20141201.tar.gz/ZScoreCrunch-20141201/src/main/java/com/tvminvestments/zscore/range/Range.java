package com.tvminvestments.zscore.range;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * sample and tracking iterator, main interface
 *
 * Created by horse on 25/10/14.
 */
public class Range {

    private static final Logger logger = LogManager.getLogger(Range.class);

    private final RangeGenerator trackingGenerator;
    private final RangeGenerator sampleGenerator;
    protected final int minDate;
    protected final int maxDate;
    private boolean sampleFirstCalc = true;

    public Range(int minDate, int maxDate, RangeGenerator sample, RangeGenerator tracking) {
        this.minDate = minDate;
        this.maxDate = maxDate;
        sampleGenerator = sample;
        trackingGenerator = tracking;

        sampleGenerator.setMaxDate(maxDate);
        sampleGenerator.setMinDate(minDate);
        // calculate here to generate end date - used as min date for tracking range
        sampleGenerator.calculateBounds();

        trackingGenerator.setMinDate(sampleGenerator.getEndDate());
        trackingGenerator.setMaxDate(maxDate);

    }

    public RangeBoundsPair next() {
        RangeBounds sampleRangeBounds = sampleGenerator.next();
        if(sampleGenerator.isOutOfBounds()) {
            logger.debug("sampleGenerator out of bounds");
            return null;
        }

        trackingGenerator.setMinDate(sampleGenerator.getEndDate());
        RangeBounds trackingRangeBounds = trackingGenerator.next();
        if(trackingGenerator.isOutOfBounds()) {
            logger.debug("trackingGenerator out of bounds");
            return null;
        }

        return new RangeBoundsPair(sampleRangeBounds, trackingRangeBounds);
    }

    @Override
    public String toString() {
        return "Range{" +
                "minDate=" + minDate +
                ", maxDate=" + maxDate +
                '}';
    }
}
