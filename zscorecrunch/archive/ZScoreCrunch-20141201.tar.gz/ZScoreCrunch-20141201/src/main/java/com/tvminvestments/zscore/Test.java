package com.tvminvestments.zscore;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.net.UnknownHostException;

/**
 * Created by horse on 18/11/14.
 */
public class Test {
    private static final Logger logger = LogManager.getLogger(Test.class);

    public static void main(String[] args) throws UnknownHostException {
        Database.init("NYSE");
        for(String symbol : Database.listSymbols()) {

            logger.info("symbol: "+symbol);

            DBCollection coll = Database.getZScoreCollection(symbol);
            //coll.drop();


            coll.dropIndexes();
            coll.createIndex(new BasicDBObject("start_date", 1));
            coll.createIndex(new BasicDBObject("data_date", 1));
//            coll.createIndex(new BasicDBObject("start_date", 1), new BasicDBObject("data_date", 1));

        }

    }

    public static void o(double d) {
        System.out.println(d);

    }

    public static void o(String s){
        System.out.println(s);
    }
}
