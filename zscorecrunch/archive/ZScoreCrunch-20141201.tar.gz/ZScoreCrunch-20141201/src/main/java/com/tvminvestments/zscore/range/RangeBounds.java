package com.tvminvestments.zscore.range;

/**
 * Created by matt on 28/10/14.
 */
public class RangeBounds {
    private final int min;
    private final int max;

    public RangeBounds(int min, int max) {
        this.min = min;
        this.max = max;
    }

    public int getMin() {
        return min;
    }

    public int getMax() {
        return max;
    }

    @Override
    public String toString() {
        return "RangeBounds{" +
                "min=" + min +
                ", max=" + max +
                '}';
    }
}
