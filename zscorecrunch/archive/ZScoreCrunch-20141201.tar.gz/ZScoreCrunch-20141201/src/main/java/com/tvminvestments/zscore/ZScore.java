package com.tvminvestments.zscore;

import com.tvminvestments.zscore.scenario.CSVScenarioFactory;
import org.apache.commons.lang3.time.StopWatch;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * ZScore command line program
 *
 * Created by horse on 13/11/14.
 */
public class ZScore {

    /**
     * A note on execution time vs number of threads (tested with NYSE_1999.zip files):
     * 1 thread - 31 seconds
     * numCPU threads - 13.6 seconds
     * floor(numCPU * 1.5) - 13.06 seconds
     * numCPU * 2 threads - 13.48 seconds
     * numCPU * 4 threads - 15.31
     */
    private static final int nThreads = (int) Math.floor(Runtime.getRuntime().availableProcessors() * 1.5);

    private static final Logger logger = LogManager.getLogger(ZScore.class);

    public static void main(String[] args) throws Exception {
        if(args == null || args.length != 2) {
            System.out.println("Usage: ZScore [EXCHANGE] [OUTFILE]");
            return;
        }

        String outFilePath = args[1];
        Database.init(args[0]);

        Database.clearResults();

        Set<String> symbols = Database.listSymbols();
        //Set<String> symbols = new HashSet<String>();
        //symbols.add("ISLE");
        ExecutorService executorService = Executors.newFixedThreadPool(nThreads);

        StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        for(final String symbol : symbols) {
            executorService.submit(new Runnable() {

                @Override
                public void run() {
                    ZScoreAlgorithm algo = new ZScoreAlgorithm(symbol, new CSVScenarioFactory());
                    try {
                        algo.zscore();
                        logger.info("["+symbol+"] ZScore calc finished! "+Database.getZScoreCollection(symbol).count()+" zscores total");

                        Database.updateZScoreIndex(symbol);

                        //algo.search(-2, 2);
                        algo.inMemSearch(-2, 2);
                    } catch(Exception e) {
                        logger.error("["+symbol+"] b0rked", e);
                    }
                }
            });
        }
        logger.info("All jobs submitted in "+stopWatch.toString());
        executorService.shutdown();
        executorService.awaitTermination(Integer.MAX_VALUE, TimeUnit.DAYS);
        stopWatch.stop();
        logger.info("ZScore completed in "+stopWatch.toString());

        /*
        stopWatch.reset();
        logger.info("Creating output file...");
        stopWatch.start();
        SearchResults.writeResult(outFilePath);
        logger.info("Wrote file in "+stopWatch.toString());
        */
    }
}
