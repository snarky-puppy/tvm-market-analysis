package com.tvminvestments.zscore;

import com.mongodb.*;
import org.apache.commons.lang3.time.StopWatch;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.UnknownHostException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * Import utility
 * Created by horse on 5/11/14.
 */
public class ImportCSVData {

    /**
     * A note on execution time vs number of threads (tested with 4090 files):
     * 1 thread - 15 mins
     * 16 threads - 7:14
     * 32 threads - 7:30
     */

    private static final int nThreads = Runtime.getRuntime().availableProcessors() * 2;

    private static final int closeIndex = 5;
    private static final int symIndex = 0;
    private static final int dateIndex = 1;

    private static HashMap<String, BulkWriteOperation> collections;

    public static void main(String[] args) throws IOException {

        int count = 0;

        if(args == null || args.length != 2) {
            System.out.println("Usage: ImportCSV [EXCHANGE] [DIR_CONTAINING_CSV_FILES]");
            return;
        }

        final String market = args[0];
        String path = args[1];
        DirectoryStream<Path> stream = Files.newDirectoryStream(Paths.get(path), "*.csv");

        Database.init(market);

        collections = new HashMap<String, BulkWriteOperation>();

        StopWatch stopWatch = new StopWatch();
        stopWatch.start();

        ExecutorService executorService = Executors.newFixedThreadPool(nThreads);

        for(final Path entry : stream) {
            executorService.submit(new Runnable() {
                @Override
                public void run() {
                    try {
                        readCSVFile(entry);
                    } catch (IOException e) {
                        System.out.println("b0rked");
                        e.printStackTrace();
                    }
                }
            });
            count++;
        }
        executorService.shutdown();
        try {
            executorService.awaitTermination(Integer.MAX_VALUE, TimeUnit.DAYS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("Writing data...");
        for(BulkWriteOperation bulk : collections.values()) {
            bulk.execute(WriteConcern.ACKNOWLEDGED);
        }

        stopWatch.stop();
        System.out.println("Processed "+count+" files in "+stopWatch.toString());

        stopWatch.reset();
        stopWatch.start();
        Database.updateDataIndexes();
        stopWatch.stop();
        System.out.println("Index update took  "+stopWatch.toString());
    }

    private static void readCSVFile(Path fileName) throws IOException {

        boolean first = true;
        String line;
        int counter = 0;

        System.out.println("Processing "+fileName.toString());

        BufferedReader br = new BufferedReader(new FileReader(fileName.toString()));
        while((line = br.readLine()) != null) {
            if(first) {
                first = false;

            } else {
                String[] data = line.split(",");
                String symbol = data[symIndex];
                String date = data[dateIndex];
                double close = Double.parseDouble(data[closeIndex]);

                DateTimeFormatter formatter = DateTimeFormat.forPattern("dd MMM yyyy");
                DateTime dt = formatter.parseDateTime(date);
                int formattedDate = DateUtil.dateTimeToInteger(dt);


                insert(symbol, Database.getInsertDataDocument(formattedDate, close));

                counter++;
            }
        }
        System.out.println(fileName.toString()+": Processed "+counter+" symbols.");
    }

    private synchronized static void insert(String symbol, DBObject doc) throws UnknownHostException {
        if(!collections.containsKey(symbol)) {
            collections.put(symbol, Database.getDataCollection(symbol).initializeOrderedBulkOperation());
        }
        collections.get(symbol).insert(doc);
        //Database.insertData(collections.get(symbol), formattedDate, close);
    }
}
