package com.tvminvestments.zscore;

import java.net.UnknownHostException;
import java.util.Set;

/**
 * Created by horse on 28/11/14.
 */
public class CheckProgress {

    public static void main(String[] args) throws UnknownHostException {
        Database.init("NYSE");

        Set<String> symbols = Database.listSymbols();
        int zTables = 0;

        Set<String> collectionNames = Database.getDB().getCollectionNames();


        for(String sym : Database.listSymbols()) {
            if(collectionNames.contains(Database.getZScoreCollectionName(sym)))

                zTables++;
        }

        System.out.println(zTables+" out of "+symbols.size());
    }
}
