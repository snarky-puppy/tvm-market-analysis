package com.tvminvestments.zscore;

import com.tvminvestments.zscore.range.RangeBounds;
import com.tvminvestments.zscore.range.RangeBoundsPair;
import com.tvminvestments.zscore.scenario.AbstractScenarioFactory;
import com.tvminvestments.zscore.scenario.Scenario;
import org.apache.commons.math3.stat.descriptive.SummaryStatistics;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.*;

/**
 * Algorithm container class
 *
 * Created by horse on 13/11/14.
 */
public class ZScoreAlgorithm {
    private static final Logger logger = LogManager.getLogger(ZScoreAlgorithm.class);

    private final String symbol;
    private final AbstractScenarioFactory scenarioFactory;

    private int minScenarioDate;
    private int maxScenarioDate;

    public ZScoreAlgorithm(String symbol, AbstractScenarioFactory scenarioFactory) {
        this.scenarioFactory = scenarioFactory;
        this.symbol = symbol;
        minScenarioDate = 0;
        maxScenarioDate = 0;
    }

    public void zscore() throws Exception {
        Map<Integer, Integer> ranges = extractScenarioRanges();

        if(ranges.size() == 0) {
            logger.info("["+symbol+"]: no scenarios");
            return;
        }

        // lazy load data - check data bounds vs max zscore
        CloseData data = null;
        RangeBounds bounds = Database.findDataBounds(symbol);
        Map<Integer, ZScoreEntry> zscores = new HashMap<Integer, ZScoreEntry>();

        logger.info("["+symbol+"] data bounds: "+bounds.getMin()+"-"+bounds.getMax());


        for(int startDate : ranges.keySet()) {
            int count = 0;
            int endDate = ranges.get(startDate);

            logger.info("["+symbol+"] scenario range: "+startDate+"-"+endDate);

            if(startDate < bounds.getMin()) {
                logger.info("["+symbol+"] Scenario start date is before data start date ("+bounds.getMin()+"-"+bounds.getMax()+"). Skipping.\n");
                continue;
            }

            if(endDate <= bounds.getMin()) {
                logger.info("["+symbol+"] Scenario end date is before data start date ("+bounds.getMin()+"-"+bounds.getMax()+"). Skipping.\n");
                continue;
            }

            if(startDate > bounds.getMax()) {
                logger.info("["+symbol+"] Scenario start date is after data end date ("+bounds.getMin()+"-"+bounds.getMax()+"). Skipping.\n");
                continue;
            }

            int zscoreMaxDate = Database.findMaxZScoreDataDate(symbol, startDate);

            logger.info("["+symbol+"] start zscore calc from: "+zscoreMaxDate);

            // if last zscore date >= scenario end date, we can skip this
            if(zscoreMaxDate >= endDate) {
                logger.info("["+symbol+"] scenario range already calculated.\n");
                continue;
            }

            // optimisation, check if zscore is up to date *before* loading the full set of zscores.
            if(bounds.getMax() <= zscoreMaxDate) {
                logger.error("["+symbol+"] Not enough available data to do anything. Skipping.\n");
                continue;
            }

            // made it this far, must need to load the data. so do it.
            if(data == null) // possibly save a data load if this scenario is completed
                data = Database.loadData(symbol, minScenarioDate, maxScenarioDate);

            int zscoreStartDate = DateUtil.addDays(zscoreMaxDate, 1);

            int startIndex = data.findDateIndex(startDate);
            if(startIndex == -1) {
                logger.error("["+symbol+"] Could not find start date: "+startDate);
                continue;
            }


            // should not fail
            int calcIndex = data.findDateIndex(zscoreStartDate, false);
            if(calcIndex == -1) {
                logger.error("["+symbol+"] Could not find index for starting date: "+zscoreStartDate+"\n");
                continue;
            }

            // should not fail
            int calcEndIndex = data.findDateIndex(endDate);
            if(calcEndIndex == -1) {
                logger.error("["+symbol+"] Could not find end date: "+endDate+"\n");
                continue;
            }

            // take into account weekends etc... indexes may not match precisely with dates
            if(calcEndIndex == calcIndex) {
                logger.error("["+symbol+"] already up to date within limits of available data. Skipping.\n");
                continue;
            }

            // everything in order, now start cranking:
            int numZScores = calcEndIndex - calcIndex;
            if(calcIndex != startIndex) {
                numZScores += 1;
            }
            // startIndex == calcIndex - guaranteed there will be a NaN for first value
            ZScoreEntry entry = new ZScoreEntry(calcEndIndex - calcIndex + 1);
            zscores.put(startDate, entry);
            SummaryStatistics stats = new SummaryStatistics();

            // preload stats thing
            while(startIndex < calcIndex) {
                stats.addValue(data.close[startIndex++]);
            }

            logger.info(String.format("calcIndex=%d, calcEndIndex=%d", calcIndex, calcEndIndex));
            logger.info(String.format("from=%d, to=%d", data.date[calcIndex], data.date[calcEndIndex]));


            while(calcIndex <= calcEndIndex) {
                stats.addValue(data.close[calcIndex]);

                double stdev = stats.getStandardDeviation();
                if(stdev == 0) {
                    logger.debug(String.format("NaN: %d", data.date[calcIndex]));
                    // either this is the first value or all initial values this far have had no variance (were the same)
                    entry.addZScore(-1, 0);
                    calcIndex ++;
                    continue;
                }
                double avg = stats.getMean();
                double closeValue = data.close[calcIndex];
                double zscore = (closeValue - avg) / stdev;

                //logger.debug(String.format("z: %d, %f, ci=%d, cei=%d", data.date[calcIndex], zscore, calcIndex, calcEndIndex));
                entry.addZScore(data.date[calcIndex], zscore);
                count++;
                calcIndex++;
            }
            if(count != numZScores)
                logger.warn("Sanity check failed: count != numZScores ("+count+" != "+numZScores+")");
            logger.info("calculated "+count+" zscores\n");
        }
        Database.insertZScores(symbol, zscores);

    }

    /**
     * Returns a map k=start_date v=end_date representing all the ranges present in our bundle of scenarios.
     *
     * Bonus: Reduces scenarios with the same starting date.
     */
    private Map<Integer, Integer> extractScenarioRanges() throws Exception {
        int scenarioCount = 0;
        Set<Scenario> scenarios = scenarioFactory.getScenarios(symbol);
        Map<Integer, Integer> ranges = new HashMap<Integer, Integer>();

        for(Scenario s : scenarios) {
            //logger.info(s);
            RangeBoundsPair bounds;
            if(s.range != null) {
                // old skool
                while ((bounds = s.range.next()) != null) {
                    scenarioCount++;
                    Integer start = bounds.getSample().getMin();
                    Integer end = bounds.getTracking().getMax();
                    filterScenario(start, end, ranges);
                }
            } else {
                // new skool
                scenarioCount++;
                filterScenario(s.sampleStart, s.trackingEnd, ranges);

            }
        }
        logger.info("["+symbol+"] reduced "+scenarioCount+" scenarios to "+ranges.size()+" ranges");
        return ranges;
    }

    private void filterScenario(int start, int end, Map<Integer, Integer> ranges) {
        // find min/max to reduce data loading
        if (start < minScenarioDate || minScenarioDate == 0)
            minScenarioDate = start;
        if (end > maxScenarioDate)
            maxScenarioDate = end;

        if (ranges.containsKey(start)) {
            if (end > ranges.get(start)) {
                ranges.put(start, end);
            }
        } else {
            ranges.put(start, end);
        }
    }


    public void search(int entryLimit, int exitLimit) throws Exception {
        Set<Scenario> scenarios = scenarioFactory.getScenarios(symbol);
        Map<String,SearchResult> results = new HashMap<String, SearchResult>();

        for(Scenario scenario : scenarios) {
            logger.info("["+symbol+"] searching scenario: "+scenario);

            int iterations = 0;
            boolean go = true;
            int startDate = scenario.trackingStart;
            while(go) {
                EntryExitPair entry = Database.findZScoreEntry(symbol, scenario, startDate, entryLimit);
                if(entry == null) {
                    if(iterations == 0) {
                        Database.addResult(symbol, scenario, new EntryExitPair(ResultCode.NO_ENTRY));
                    }
                    go = false;
                    continue;
                }
                logger.debug("Found entry: "+entry);

                EntryExitPair exit = Database.findZScoreExit(symbol, scenario, entry.entryDate, exitLimit);
                if(exit == null) {
                    entry.resultCode = ResultCode.ENTRY_NO_EXIT;
                    Database.addResult(symbol, scenario, entry);
                    go = false;
                    continue;
                }
                logger.debug("Found exit: "+exit);


                entry.resultCode = ResultCode.ENTRY_EXIT;
                entry.mergeExit(exit);
                Database.addResult(symbol, scenario, entry);

                // prepare for next run at it
                startDate = exit.exitDate;
                iterations ++;
            }
        }
        //SearchResults.mergeResults(results);

    }

    public void inMemSearch(int entryLimit, int exitLimit) throws Exception {
        Set<Scenario> scenarios = scenarioFactory.getScenarios(symbol);

        Map<Integer, ZScoreEntry> zscores = Database.loadZScores(symbol);

        for(Scenario scenario : scenarios) {
            logger.info("["+symbol+"] searching scenario: "+scenario);
            if(!zscores.containsKey(scenario.sampleStart)) {
                logger.debug("["+symbol+"]: No zscore data for scenario");
                Database.addResult(symbol, scenario, new EntryExitPair(ResultCode.NO_ENTRY));
                continue;
            }
            ZScoreEntry zscore = zscores.get(scenario.sampleStart);

            int iterations = 0;
            boolean go = true;
            int idx = zscore.findClosestDateIndex(scenario.trackingStart);

            if(idx == -1) {
                logger.debug("["+symbol+"]: Not enough zscore data for scenario (no tracking start date)");
                Database.addResult(symbol, scenario, new EntryExitPair(ResultCode.NO_ENTRY));
                continue;
            }

            logger.info("ZScore Search, start="+zscore.date[idx]);

            while(go) {

                if(idx >= zscore.date.length || zscore.date[idx] > scenario.trackingEnd) {
                    if(iterations == 0) {
                        Database.addResult(symbol, scenario, new EntryExitPair(ResultCode.NO_ENTRY));
                    }
                    go = false;
                    continue;
                }

                int entry = zscore.findIndexOfZScoreLTE(idx, entryLimit, scenario.trackingEnd);
                if(entry == -1) {
                    if(iterations == 0) {
                        Database.addResult(symbol, scenario, new EntryExitPair(ResultCode.NO_ENTRY));
                    }
                    go = false;
                    continue;
                }

                EntryExitPair pair = new EntryExitPair(ResultCode.ENTRY_NO_EXIT);
                pair.entryDate = zscore.date[entry];
                pair.entryZScore = zscore.zscore[entry];
                pair.entryPrice = Database.findClosePrice(symbol, pair.entryDate);

                logger.debug("Found entry: "+entry);

                int exit = zscore.findIndexOfZScoreGTE(entry, exitLimit, scenario.trackingEnd);
                if(exit < 0) {
                    exit = -exit;
                    pair.exitDate = zscore.date[exit];
                    pair.exitZScore = zscore.zscore[exit];
                    pair.exitPrice = Database.findClosePrice(symbol, pair.exitDate);

                    Database.addResult(symbol, scenario, pair);
                    go = false;
                    continue;
                }

                pair.resultCode = ResultCode.ENTRY_EXIT;
                pair.exitDate = zscore.date[exit];
                pair.exitZScore = zscore.zscore[exit];
                pair.exitPrice = Database.findClosePrice(symbol, pair.exitDate);

                logger.debug("Found exit: "+exit);

                Database.addResult(symbol, scenario, pair);

                // prepare for next run at it
                idx = exit;
                iterations ++;
            }
        }
        //SearchResults.mergeResults(results);

    }
}
