package com.tvminvestments.zscore;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

/**
 * Created by horse on 30/11/14.
 */
public class ExportResults {
    private static final Logger logger = LogManager.getLogger(ExportResults.class);


    public static void main(String[] args) throws IOException {
        if(args == null || args.length != 2) {
            System.out.println("Usage: ExportResults [EXCHANGE] [OUTFILE]");
            return;
        }

        Database.init(args[0]);
        String outFile = args[1];

        BufferedWriter bw = new BufferedWriter(new FileWriter(outFile));
        bw.write("Symbol,Scenario ID,Sub-scenario"+
                ",Sample Start Date,Tracking Start Date,Tracking End Date"+
                ",Result Code,Entry Date,Entry ZScore,Entry Price,Exit Date,Exit ZScore,Exit Price"+
                "\n");

        Database.writeResults(bw);

        bw.close();
    }

}
