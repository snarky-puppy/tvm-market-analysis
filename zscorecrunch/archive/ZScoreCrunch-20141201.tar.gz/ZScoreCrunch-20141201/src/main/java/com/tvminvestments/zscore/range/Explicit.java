package com.tvminvestments.zscore.range;

/**
 * Constant range, start and end specified explicitly.
 *
 * Created by matt on 31/10/14.
 */
public class Explicit extends RangeGenerator {

    public Explicit(int startDate, int endDate) {
        this.startDate = startDate;
        this.endDate = endDate;
    }

    @Override
    protected void calculateBounds() {
        // nothing to calculate, start/end explicitly given
    }

    @Override
    public boolean isOutOfBounds() {
        // Disable checking for this. Assume that I know what I'm doing.
        //return startDate <= getMinDate() || endDate >= getMaxDate();
        return false;
    }

}
