package com.tvminvestments.zscore;

/**
 * The data contained in this structure will eventually become a row in a .csv file
 *
 * @see com.tvminvestments.zscore.SearchResult
 *
 * Created by horse on 26/11/14.
 */
public class EntryExitPair {

    public ResultCode resultCode;

    public double entryZScore;
    public int entryDate;
    public double entryPrice;

    public double exitZScore;
    public int exitDate;
    public double exitPrice;

    public EntryExitPair(ResultCode resultCode) {
        this.resultCode = resultCode;
    }

    public EntryExitPair() {

    }

    public void mergeExit(EntryExitPair exit) {
        exitZScore = exit.exitZScore;
        exitDate = exit.exitDate;
        exitPrice = exit.exitPrice;
    }

    @Override
    public String toString() {
        return "EntryExitPair{" +
                "resultCode=" + resultCode +
                ", entryZScore=" + entryZScore +
                ", entryDate=" + entryDate +
                ", entryPrice=" + entryPrice +
                ", exitZScore=" + exitZScore +
                ", exitDate=" + exitDate +
                ", exitPrice=" + exitPrice +
                '}';
    }
}
