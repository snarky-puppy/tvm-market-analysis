package com.tvminvestments.zscore.range;

import com.tvminvestments.zscore.DateUtil;

/**
 * Range where the start is a fixed date, and the end increases.
 *
 * Created by matt on 31/10/14.
 */
public class StartMinEndIncrease extends RangeGenerator {

    private final int startSize;

    public StartMinEndIncrease(int startSize) {
        this.startSize = startSize;
    }

    @Override
    protected void calculateBounds() {
        int n = 0;
        if(getCount() > 0)
            n = getCount();
        startDate = getMinDate();
        endDate = DateUtil.addYears(getMinDate(), startSize + n);
    }

    @Override
    public boolean isOutOfBounds() {
        return endDate > getMaxDate();
    }
}
