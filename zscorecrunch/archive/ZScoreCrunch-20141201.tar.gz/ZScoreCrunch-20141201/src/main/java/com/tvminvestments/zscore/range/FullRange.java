package com.tvminvestments.zscore.range;

/**
 * A RangeGenerator that covers the full range of data
 *
 * Created by matt on 20/11/14.
 */
public class FullRange extends RangeGenerator {
    private boolean once = false;
    @Override
    protected void calculateBounds() {
        startDate = getMinDate();
        endDate = getMaxDate();
    }

    @Override
    public boolean isOutOfBounds() {
        if(!once) {
            once = true;
            return false;
        }
        return true;
    }
}
