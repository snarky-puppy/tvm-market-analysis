package com.tvminvestments.zscore;

import com.mongodb.*;
import com.tvminvestments.zscore.range.RangeBounds;
import com.tvminvestments.zscore.scenario.Scenario;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.BufferedWriter;
import java.io.IOException;
import java.net.UnknownHostException;
import java.util.*;

/**
 * Created by matt on 28/10/14.
 */
public class Database {

    private static final Logger logger = LogManager.getLogger(Database.class);

    public static String market;
    private static MongoClient client;

    static Boolean resultIndexCheck = false;


    static {
        try {
            client = new MongoClient();
            //client.setWriteConcern(WriteConcern.UNACKNOWLEDGED);
        } catch (UnknownHostException e) {
            e.printStackTrace();
            System.exit(-1);
        }
    }

    public static void init(String market) {
        Database.market = market;
    }

    public static DB getDB() throws UnknownHostException {
        return client.getDB(market);
    }

    public static DBCollection getDataCollection(String symbol) throws UnknownHostException {
        return getDB().getCollection(getDataCollectionName(symbol));
    }

    public static DBCollection getZScoreCollection(String symbol) throws UnknownHostException {
        return getDB().getCollection(getZScoreCollectionName(symbol));
    }


    public static DBCollection getResultsCollection() throws UnknownHostException {
        return getDB().getCollection("results");
    }

/*
    public static DBCollection getResultsCollection(String symbol) throws UnknownHostException {
        return getDB().getCollection(getResultsCollectionName(symbol));
    }

    public static DBCollection getPairsCollection(String symbol) throws UnknownHostException {
        return getDB().getCollection(getPairsCollectionName(symbol));
    }
*/

    public static String getDataCollectionName(String symbol) {
        return symbol + "_data";
    }

    public static String getZScoreCollectionName(String symbol) {
        return symbol + "_zscore";
    }
/*
    public static String getResultsCollectionName(String symbol) {
        return symbol + "_result";
    }

    public static String getPairsCollectionName(String symbol) {
        return symbol + "_pairs";
    }
*/


    public static Set<String> listSymbols() throws UnknownHostException {
        Set<String> names = getDB().getCollectionNames();
        Set<String> rv = new HashSet<String>();
        for(String s : names) {
            if(s.matches("^system.*"))
                continue;
            rv.add(s.split("_")[0]);
        }
        return rv;
    }


    public static RangeBounds findDataBounds(String symbol) throws UnknownHostException {
        DBCollection coll = getDataCollection(symbol);

        DBObject groupFields = new BasicDBObject("_id", null);
        groupFields.put("min", new BasicDBObject("$min", "$date"));
        groupFields.put("max", new BasicDBObject("$max", "$date"));
        DBObject group = new BasicDBObject("$group", groupFields);

        List<DBObject> pipeline = Arrays.asList(group);
        AggregationOutput output = coll.aggregate(pipeline);

        for(DBObject result : output.results()) {
            int min = 0, max = 0;
            min = (Integer) result.get("min");
            max = (Integer) result.get("max");
            return new RangeBounds(min, max);
        }

        return null;
    }

    /**
     * Insert a data record, ensures the schema is correct in this file.
     *  @param collection
     * @param date
     * @param close
     */
    public static void insertData(DBCollection collection, int date, double close) {
        collection.insert(getInsertDataDocument(date, close));
    }

    public static void updateDataIndexes() throws UnknownHostException {
        for(String symbol : listSymbols()) {
            //logger.debug("Updating index on "+symbol);
            getDataCollection(symbol).createIndex(new BasicDBObject("date", 1));
        }
    }

    /**
     * Load a table of zscore entries. Returns a Map where k=zscore_start_date, v=zscore_run
     *
     * mongo zscore document: {start_date, data_date, zscore}
     *
     * @param symbol
     * @return
     * @throws UnknownHostException
     */
    public static Map<Integer, ZScoreEntry> loadZScores(String symbol) throws UnknownHostException {
        DBCollection coll = getZScoreCollection(symbol);
        List<Integer> startDates = coll.distinct("start_date");
        Map<Integer, ZScoreEntry> zscores = new HashMap<Integer, ZScoreEntry>(startDates.size());

        for (int startDate : startDates) {
            DBCursor cursor = coll.find(new BasicDBObject("start_date", startDate));
            ZScoreEntry entry = new ZScoreEntry(cursor.size());
            zscores.put(startDate, entry);

            cursor.sort(new BasicDBObject("data_date", 1));
            try {
                while (cursor.hasNext()) {
                    DBObject object = cursor.next();
                    int dataDate = (Integer) object.get("data_date");
                    double z = (Double) object.get("zscore");

                    entry.addZScore(dataDate, z);
                }
                entry.sanity();
            } finally {
                cursor.close();
            }
        }

        return zscores;
    }

    public static void insertZScores(String symbol, Map<Integer, ZScoreEntry> zscores) throws UnknownHostException {
        DBCollection coll = getZScoreCollection(symbol);
        BulkWriteOperation bulk = coll.initializeOrderedBulkOperation();
        boolean notEmpty = false;
        for(Integer startDate : zscores.keySet()) {
            ZScoreEntry entry = zscores.get(startDate);
            if(entry == null || entry.date.length == 0)
                continue;
            entry.sanity();
            for(int i = 0; i < entry.date.length; i++) {
                if(entry.date[i] != -1) { // denotes n/a zscore, such as when stdev() returns 0
                    bulk.insert(new BasicDBObject("start_date", startDate)
                            .append("data_date", entry.date[i])
                            .append("zscore", entry.zscore[i]));
                    notEmpty = true;
                }
            }
        }
        if(notEmpty)
            bulk.execute(WriteConcern.ACKNOWLEDGED);
        //coll.createIndex(new BasicDBObject("start_date", 1));
        //coll.createIndex(new BasicDBObject("data_date", 1));
        //coll.createIndex(new BasicDBObject(new BasicDBObject("start_date", 1), new BasicDBObject("data_date", 1)));
    }

    public static CloseData loadData(String symbol) throws UnknownHostException {
        return loadData(symbol, null);
    }

    public static CloseData loadData(String symbol, int minDate, int maxDate) throws UnknownHostException {
        logger.debug(String.format("[%s] loadData: minDate=%d, maxDate=%d", symbol, minDate, maxDate));
        return loadData(symbol,
                new BasicDBObject("date", new BasicDBObject("$gte", minDate))
                    .append("date", new BasicDBObject("$lte", maxDate)));
    }

    public static CloseData loadData(String symbol, DBObject query) throws UnknownHostException {
        DBCollection coll = getDataCollection(symbol);
        DBCursor cursor;
        if(query != null)
            cursor = coll.find(query);
        else
            cursor = coll.find();

        cursor.sort(new BasicDBObject("date", 1));
        CloseData closeData = new CloseData(cursor.count());
        try {
            int i = 0;
            while(cursor.hasNext()) {
                DBObject object = cursor.next();

                int date = (Integer) object.get("date");
                double close = (Double) object.get("close");

                closeData.date[i] = date;
                closeData.close[i] = close;
                i++;
            }
            logger.info("["+symbol+"] loaded "+i+" data records");
        } finally {
            cursor.close();
        }

        closeData.sanity();
        return closeData;

    }

    // in other words, do we have any zscore to calculate?
    public static int findMaxZScoreDataDate(String symbol, int startDate) throws UnknownHostException {
        DBCollection coll = getZScoreCollection(symbol);

        // empty zscore table, there's no chance
        if(coll.count() == 0) {
            logger.debug("["+symbol+"]: empty collection - zscore range cannot possibly exist");
            return startDate;
        }

        // within zscore range, find largest data_date where data_date < endDate
        DBObject groupFields = new BasicDBObject("_id", null);
        groupFields.put("data_date", new BasicDBObject("$max", "$data_date"));
        DBObject group = new BasicDBObject("$group", groupFields);
        DBObject match = new BasicDBObject("$match", new BasicDBObject("start_date", startDate));

        List<DBObject> pipeline = Arrays.asList(match, group);
        AggregationOutput output = coll.aggregate(pipeline);

        for(DBObject result : output.results()) {
            int maxDate = (Integer) result.get("data_date");
            return maxDate;

        }
        return startDate;

    }


    private static DBObject findZScoreLimit(String symbol, Scenario scenario, int startDate, int limit, String limitOp) throws Exception {
        DBCollection coll = getZScoreCollection(symbol);

        // empty zscore table, there's no chance
        if(coll.count() == 0) {
            logger.debug("["+symbol+"]: empty collection - zscore range cannot possibly exist");
            return null;
        }

        // find first zscore <= entryLimit
        List<BasicDBObject> searchArguments = new ArrayList<BasicDBObject>();
        searchArguments.add(new BasicDBObject("data_date", new BasicDBObject("$gte", startDate)));
        searchArguments.add(new BasicDBObject("data_date", new BasicDBObject("$lte", scenario.trackingEnd)));

        BasicDBObject query = new BasicDBObject("start_date", scenario.sampleStart)
                .append("$and", searchArguments)
                .append("zscore", new BasicDBObject(limitOp, limit));
        //DBCursor cursor = coll.find(query).addSpecial("$orderby", new BasicDBObject("date", 1)).limit(1);

        return coll.findOne(query);
    }

    public static EntryExitPair findZScoreEntry(String symbol, Scenario scenario, int startDate, int entryLimit) throws Exception {
        EntryExitPair pair = null;
        DBObject object = findZScoreLimit(symbol, scenario, startDate, entryLimit, "$lte");
        if(object != null) {
            pair = new EntryExitPair();
            pair.entryDate = (Integer) object.get("data_date");
            pair.entryZScore = (Double) object.get("zscore");
            pair.entryPrice = findClosePrice(symbol, pair.entryDate);
        }
        return pair;
    }


    public static EntryExitPair findZScoreExit(String symbol, Scenario scenario, int startDate, int exitLimit) throws Exception {
        EntryExitPair pair = null;
        DBObject object = findZScoreLimit(symbol, scenario, startDate, exitLimit, "$gte");
        if(object != null) {
            pair = new EntryExitPair();
            pair.exitDate = (Integer) object.get("data_date");
            pair.exitZScore = (Double) object.get("zscore");
            pair.exitPrice = findClosePrice(symbol, pair.exitDate);
        }
        return pair;
    }

    public static void updateZScoreIndex(String symbol) throws UnknownHostException {
        DBCollection coll = getZScoreCollection(symbol);
        coll.createIndex(new BasicDBObject("start_date", 1));
        coll.createIndex(new BasicDBObject("data_date", 1));
    }


    public static double findClosePrice(String symbol, int date) throws Exception {
        DBCollection coll = getDataCollection(symbol);
        DBObject object = coll.findOne(new BasicDBObject("date", date));
        if(object != null)
            return (Double) object.get("close");
        throw new Exception("Should not be possible - zscore has no corresponding data ("+date+")");
    }

    public static DBObject getInsertDataDocument(int date, double close) {
        return new BasicDBObject("date", date)
                .append("close", close);
    }

    public static void clearResults() throws UnknownHostException {
        getResultsCollection().drop();
    }

    public static void addResult(String symbol, Scenario scenario, EntryExitPair entryExitPair) throws UnknownHostException {
        DBCollection resultsCollection = getResultsCollection();


        // update
        DBObject resultDoc = new BasicDBObject("symbol", symbol)
                .append("scenario", scenario.name)
                .append("sub_scenario", scenario.subScenario)
                .append("sample_start_date", scenario.sampleStart)
                .append("tracking_start_date", scenario.trackingStart)
                .append("tracking_end_date", scenario.trackingEnd)
                .append("result_code", entryExitPair.resultCode.toString())
                .append("entry_date", entryExitPair.entryDate)
                .append("entry_price", entryExitPair.entryPrice)
                .append("entry_zscore", entryExitPair.entryZScore)
                .append("exit_date", entryExitPair.exitDate)
                .append("exit_price", entryExitPair.exitPrice)
                .append("exit_zscore", entryExitPair.exitZScore);
        resultsCollection.insert(resultDoc);

        synchronized (resultIndexCheck) {
            resultsCollection.createIndex(new BasicDBObject("symbol", 1).append("scenario", 1).append("sub_scenario", 1).append("entry_date", 1), null, true);
            resultIndexCheck = true;

        }

        /**
         * TODO: maybe something can be done with this in future. For now, since we are only in basic analysis stage,
         * we do it dumb.
         *
         * In future, consider:
         *
         * Valid pairs sequence:
         *
         *  1. NO_ENTRY
         *  2. ENTRY_NO_EXIT
         *  3. ENTRY_EXIT
         *  4. multiple ENTRY_EXIT
         *
         *  zscore algo can use this status somehow
         *
         *
         *
         */

    }

    public static void writeResults(BufferedWriter bw) throws IOException {

        DBObject query = new BasicDBObject("result_code", new BasicDBObject("$ne", "NE"));
        DBCursor cursor = getResultsCollection().find(query);

        cursor.sort(new BasicDBObject("symbol", 1).append("scenario", 1).append("sub_scenario", 1));

        while(cursor.hasNext()) {
            DBObject obj = cursor.next();
            StringBuilder str = new StringBuilder();
            str.append((String)obj.get("symbol")); str.append(",");
            str.append((String)obj.get("scenario")); str.append(",");
            str.append((Integer)obj.get("sub_scenario")); str.append(",");
            str.append((Integer)obj.get("sample_start_date")); str.append(",");
            str.append((Integer)obj.get("tracking_start_date")); str.append(",");
            str.append((Integer)obj.get("tracking_end_date")); str.append(",");
            str.append((String)obj.get("result_code")); str.append(",");
            str.append((Integer)obj.get("entry_date")); str.append(",");
            str.append((Double)obj.get("entry_price")); str.append(",");
            str.append((Double)obj.get("entry_zscore")); str.append(",");
            str.append((Integer)obj.get("exit_date")); str.append(",");
            str.append((Double)obj.get("exit_price")); str.append(",");
            str.append((Double)obj.get("exit_zscore")); str.append("\n");
            bw.write(str.toString());
        }
    }
}
