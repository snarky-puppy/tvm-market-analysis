package com.tvminvestments.zscore.range;

import com.tvminvestments.zscore.range.RangeBounds;

/**
 * An abstract range generator. Implements the {@link #next()} method.
 *
 * Specialisations of this class implement {@link #calculateBounds()} and {@link #isOutOfBounds()}
 *
 * Created by matt on 28/10/14.
 */
public abstract class RangeGenerator {
    // iteration counter
    private int count;

    // min/max date of data
    private int maxDate;
    private int minDate;

    // calculated start and end dates (range assumed to be within minDate/maxDate)
    protected int startDate;
    protected int endDate;

    // single shot support
    private boolean isSingleShot = false;
    private boolean once = false;

    RangeGenerator() {
        count = maxDate = minDate = startDate = endDate = -1;
    }

    public RangeGenerator singleShot() {
        isSingleShot = true;
        return this;
    }

    public boolean singleShotFired() {
        if(isSingleShot) {
            return once;
        }
        return false;
    }

    public int getMaxDate() {
        return maxDate;
    }

    public void setMaxDate(int maxDate) {
        this.maxDate = maxDate;
    }

    public int getMinDate() {
        return minDate;
    }

    public void setMinDate(int minDate) {
        this.minDate = minDate;
    }

    protected abstract void calculateBounds();

    public final RangeBounds next() {
        count++;
        calculateBounds();
        once = true;
        return new RangeBounds(getStartDate(), getEndDate());
    }

    public abstract boolean isOutOfBounds();

    protected int getCount() {
        return count;
    }

    public int getStartDate() {
        if (startDate == -1)
            calculateBounds();
        return startDate;
    }

    public int getEndDate() {
        if (endDate == -1)
            calculateBounds();
        return endDate;
    }

}
