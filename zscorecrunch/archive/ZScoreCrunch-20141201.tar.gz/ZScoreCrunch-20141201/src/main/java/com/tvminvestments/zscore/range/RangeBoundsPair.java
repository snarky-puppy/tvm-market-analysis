package com.tvminvestments.zscore.range;

/**
 * Collection of sample and tracking RangeBounds objects.
 *
* Created by horse on 13/11/14.
*/
public class RangeBoundsPair {
    private final RangeBounds sample;
    private final RangeBounds tracking;

    public RangeBoundsPair(RangeBounds sample, RangeBounds tracking) {
        this.sample = sample;
        this.tracking = tracking;
    }

    public RangeBounds getSample() {
        return sample;
    }

    public RangeBounds getTracking() {
        return tracking;
    }
}
