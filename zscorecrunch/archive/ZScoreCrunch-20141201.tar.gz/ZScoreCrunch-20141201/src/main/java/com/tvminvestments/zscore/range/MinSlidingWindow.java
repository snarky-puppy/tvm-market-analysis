package com.tvminvestments.zscore.range;

import com.tvminvestments.zscore.DateUtil;

/**
 * Sliding window range. Starts from beginning of data (Min) and increases.
 *
 * Window slides incrementally, i.e. start and end date increase at same rate each iteration.
 *
 * Created by matt on 31/10/14.
 */
public class MinSlidingWindow extends RangeGenerator {
    private final int size;

    public MinSlidingWindow(int size) {
        this.size = size;
    }

    @Override
    protected void calculateBounds() {
        int n;
        if(getCount() <= 0)
            n = 0;
        else
            n = getCount();

        startDate = DateUtil.addYears(getMinDate(), n);
        endDate = DateUtil.addYears(getMinDate(), n + size);
    }

    @Override
    public boolean isOutOfBounds() {
        return endDate > getMaxDate();
    }
}
