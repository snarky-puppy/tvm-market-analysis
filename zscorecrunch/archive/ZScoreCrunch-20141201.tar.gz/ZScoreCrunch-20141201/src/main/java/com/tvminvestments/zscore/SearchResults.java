package com.tvminvestments.zscore;

import com.tvminvestments.zscore.scenario.Scenario;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.*;
import java.util.*;

/**
 * Created by horse on 26/11/14.
 */
public class SearchResults {

    /*
    private static final Logger logger = LogManager.getLogger(SearchResults.class);
    public static Map<String, SearchResult> results = new HashMap<String, SearchResult>();

    public synchronized static void mergeResults(Map<String, SearchResult> newResults) {
        results.putAll(newResults);
    }

    public static void addResult(Map<String, SearchResult> resultMap, String symbol, Scenario scenario, EntryExitPair pair) {
        String key = getKey(symbol, scenario);
        SearchResult result;

        if(resultMap.containsKey(key)) {
            result = resultMap.get(key);
        } else {
            result = new SearchResult();
            result.symbol = symbol;
            result.scenario = scenario.name;
            result.sampleStartDate = scenario.sampleStart;
            result.subScenario = scenario.subScenario;
            result.trackingStartDate = scenario.trackingStart;
            result.trackingEndDate = scenario.trackingEnd;
            result.pairs = new ArrayList<EntryExitPair>();
            resultMap.put(key, result);
        }
        result.pairs.add(pair);
    }

    private static String getKey(String symbol, Scenario scenario) {
        return symbol + "." + scenario.name + "." + Integer.toString(scenario.subScenario);
    }

    public static void writeResult(String outFilePath) throws IOException {
        BufferedWriter bw = new BufferedWriter(new FileWriter(outFilePath));
        bw.write("Symbol,Scenario ID,Sub-scenario"+
                ",Sample Start Date,Tracking Start Date,Tracking End Date"+
                ",Result Code,Entry Date,Entry ZScore,Entry Price,Exit Date,Exit ZScore,Exit Price"+
                "\n");
        List<String> keys = new ArrayList<String>(results.keySet());
        Collections.sort(keys);

        for(String k : keys) {
            bw.write(results.get(k).toString());
        }
        bw.close();
    }
    */
}
