package com.tvminvestments.zscore.range;

import com.tvminvestments.zscore.DateUtil;

/**
 * This range takes up all the space available, until it reaches a min size.
 *
 * Created by horse on 5/11/14.
 */
public class StartMinEndMax extends RangeGenerator {

    private final int minSize;

    public StartMinEndMax(int minSize) {
        this.minSize = minSize;
    }
    @Override
    protected void calculateBounds() {
        startDate = getMinDate();
        endDate = getMaxDate();
    }

    @Override
    public boolean isOutOfBounds() {
        int startYear = DateUtil.getYear(startDate);
        int endYear = DateUtil.getYear(endDate);
        return (endYear - startYear) < minSize;
    }
}
