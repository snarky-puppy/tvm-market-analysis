package com.tvminvestments.zscore.scenario;

import com.tvminvestments.zscore.Database;
import com.tvminvestments.zscore.range.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.net.UnknownHostException;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by horse on 5/11/14.
 */
public class ClassicScenarioFactory implements AbstractScenarioFactory {
    private static final Logger logger = LogManager.getLogger(ClassicScenarioFactory.class);

    @Override
    public Set<Scenario> getScenarios(String symbol) throws Exception {
        int maxDate;
        int minDate;
        Set<Scenario> rv = new HashSet<Scenario>();

        RangeBounds bounds = Database.findDataBounds(symbol);
        if(bounds == null) {
            logger.error("Not found in database: "+symbol);
            return null;
        }

        minDate = bounds.getMin();
        maxDate = bounds.getMax();

        logger.info(symbol+": min/max: "+bounds.toString());

        rv.add(new Scenario("S1", new Range(minDate, maxDate, new MinSlidingWindow(5), new StartMinEndMax(5))));
        rv.add(new Scenario("S2", new Range(minDate, maxDate, new MinSlidingWindow(5), new MinSlidingWindow(5))));
        rv.add(new Scenario("S3", new Range(minDate, maxDate, new StartMinEndIncrease(5), new StartMinEndMax(4))));
        rv.add(new Scenario("S4", new Range(minDate, maxDate, new StartMinEndIncrease(5).singleShot(), new StartMinEndMax(5))));
        rv.add(new Scenario("S5", new Range(minDate, maxDate, new StartDecreaseEndFixed(20050101, 20101231, 2), new Explicit(20110101, 20131231))));
        rv.add(new Scenario("S6", new Range(minDate, maxDate, new StartDecreaseEndFixed(19990101, 20041231, 2), new Explicit(20050101, 20071231))));
        rv.add(new Scenario("S7", new Range(minDate, maxDate, new StartDecreaseEndFixed(20000101, 20051231, 2), new Explicit(20060101, 20081231))));
        rv.add(new Scenario("S8", new Range(minDate, maxDate, new StartDecreaseEndFixed(20010101, 20061231, 2), new Explicit(20070101, 20091231))));
        rv.add(new Scenario("S9", new Range(minDate, maxDate, new StartDecreaseEndFixed(20020101, 20071231, 2), new Explicit(20080101, 20101231))));
        rv.add(new Scenario("S10", new Range(minDate, maxDate, new StartDecreaseEndFixed(20100101, 20121231, 0), new Explicit(20130101, 20141231))));
        rv.add(new Scenario("S11", new Range(minDate, maxDate, new StartDecreaseEndFixed(20000101, 20051231, 2), new Explicit(20060101, 20111231))));
        rv.add(new Scenario("S12", new Range(minDate, maxDate, new StartDecreaseEndFixed(19990101, 20041231, 2), new Explicit(20050101, 20101231))));

        return rv;
    }
}
