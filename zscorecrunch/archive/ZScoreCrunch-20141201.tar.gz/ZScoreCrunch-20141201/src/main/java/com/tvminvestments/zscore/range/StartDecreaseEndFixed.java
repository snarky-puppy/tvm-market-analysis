package com.tvminvestments.zscore.range;

import com.tvminvestments.zscore.DateUtil;

/**
 * Created by horse on 5/11/14.
 */
public class StartDecreaseEndFixed extends RangeGenerator {
    private final int myStartDate;
    private final int myFixedEndDate;
    private final int minSize;

    public StartDecreaseEndFixed(int myStartDate, int myFixedEndDate, int minSize) {
        this.myStartDate = myStartDate;
        this.myFixedEndDate = myFixedEndDate;
        this.minSize = minSize;
    }
    @Override
    protected void calculateBounds() {
        int n = 0;
        if(getCount() > 0)
            n = getCount();

        startDate = DateUtil.addYears(myStartDate, n);
        endDate = myFixedEndDate;
    }

    @Override
    public boolean isOutOfBounds() {
        int startYear = DateUtil.getYear(startDate);
        int endYear = DateUtil.getYear(endDate);
        return (endYear - startYear) < minSize;
    }
}
