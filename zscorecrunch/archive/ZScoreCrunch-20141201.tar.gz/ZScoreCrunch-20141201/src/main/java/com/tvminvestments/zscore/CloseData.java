package com.tvminvestments.zscore;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.Arrays;

/**
 * Wrap close data - date/close pairs
 *
 * Created by horse on 18/11/14.
 */
public class CloseData {
    private static final Logger logger = LogManager.getLogger(CloseData.class);

    public int[] date;
    public double[] close;

    public CloseData(int size) {
        date = new int[size];
        close = new double[size];
    }

    public int findDateIndex(int startDate) {
        return findDateIndex(startDate, true);
    }

    public int findDateIndex(int findDate, boolean softEnd) {
        if(date.length == 0) {
            logger.debug("findDate[" + findDate + "] no data found");
            return -1;
        }
        int idx = Arrays.binarySearch(date, findDate);
        if(idx >= 0) {
            return idx;
        } else {
            idx = (-idx) - 1;

            if (idx >= date.length) {
                if(softEnd) {
                    logger.debug("findDate[" + findDate + "] not found, past end of data. Returning end index (" + (date.length - 1) + ").");
                    return date.length - 1;
                } else {
                    logger.debug("findDate[" + findDate + "] not found, past end of data. Returning -1.");
                    return -1;
                }
            } else {
                logger.debug("findDate["+findDate+"] not found, next data date: "+date[idx]+" (idx="+idx+")");
                return idx;
            }
        }
    }

    public void sanity() {
        assert(date.length == close.length);
    }
}
