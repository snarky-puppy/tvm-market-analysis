package com.tvminvestments.zscore;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.joda.time.DateTime;

/**
 * Miscellaneous date functions.
 *
 * Created by matt on 29/10/14.
 */
public class DateUtil {
    private static final Logger logger = LogManager.getLogger(DateUtil.class);

    public static void assertValidDate(int date) throws IndexOutOfBoundsException {
        // If this code is still kicking around 6 years from now I will be impressed
        if(date < 19700101 || date > 20200101)
            throw new IndexOutOfBoundsException();
    }

    public static int getYear(int date) {
        return date / 10000;
    }


    private static class DateComponents {
        public int y, m, d;

        @Override
        public String toString() {
            return "DateComponents{" +
                    "y=" + y +
                    ", m=" + m +
                    ", d=" + d +
                    '}';
        }

        DateComponents(int date) {
            assertValidDate(date);
            y = getYear(date);
            m = (date - (y * 10000)) / 100;
            d = (date - (y * 10000)) - (m * 100);
        }
    }

    public static int dateTimeToInteger(DateTime dateTime) {
        return (dateTime.getYear() * 10000) +
                (dateTime.getMonthOfYear() * 100) +
                (dateTime.getDayOfMonth());
    }

    public static int addYears(int date, int numYears) {
        DateComponents dc = new DateComponents(date);
        DateTime dateTime = new DateTime(dc.y, dc.m, dc.d, 0, 0);
        return dateTimeToInteger(dateTime.plusYears(numYears));
    }

    public static int minusYears(int date, int numYears) {
        DateComponents dc = new DateComponents(date);
        DateTime dateTime = new DateTime(dc.y, dc.m, dc.d, 0, 0);
        return dateTimeToInteger(dateTime.minusYears(numYears));
    }

    public static int addDays(int date, int numDays) {
        DateComponents dc = new DateComponents(date);
        DateTime dateTime = new DateTime(dc.y, dc.m, dc.d, 0, 0);
        return dateTimeToInteger(dateTime.plusDays(numDays));
    }

    public static int minusDays(int date, int numDays) {
        DateComponents dc = new DateComponents(date);
        DateTime dateTime = new DateTime(dc.y, dc.m, dc.d, 0, 0);
        return dateTimeToInteger(dateTime.minusDays(numDays));
    }

}
