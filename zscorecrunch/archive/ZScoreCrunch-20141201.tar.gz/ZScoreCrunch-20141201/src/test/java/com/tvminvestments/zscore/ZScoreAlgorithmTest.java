package com.tvminvestments.zscore;

import com.mongodb.DBCollection;
import com.tvminvestments.zscore.scenario.Scenario;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.*;
import org.junit.Test;

import java.io.BufferedReader;
import java.io.FileReader;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.*;

public class ZScoreAlgorithmTest {

    private static final Logger logger = LogManager.getLogger(ZScoreAlgorithmTest.class);

    private static final String dataPath = "/zscores-a.csv";
    private static final String symbol = "ZScoreAlgorithmTest";

    private ArrayList<Double> zscoresFromFile;

    @Before
    public void setUp() throws Exception {
        Database.market = "test";

        zscoresFromFile = new ArrayList<Double>();

        // make sure we are clean
        Database.getDataCollection(symbol).drop();
        Database.getZScoreCollection(symbol).drop();

        DBCollection data = Database.getDataCollection(symbol);

        // load CSV data
        String path = ZScoreAlgorithmTest.class.getResource(dataPath).getPath();
        BufferedReader br = new BufferedReader(new FileReader(path));
        String line;
        boolean first = true;
        while ((line = br.readLine()) != null) {
            if (first) {
                first = false;

            } else {
                String[] tuple = line.split(",");
                int date = Integer.parseInt(tuple[0]);
                double close = Double.parseDouble(tuple[1]);
                if (tuple.length > 2) {
                    double zscore = Double.parseDouble(tuple[2]);
                    zscoresFromFile.add(zscore);
                }
                Database.insertData(data, date, close);
            }
        }
        logger.info("Inserted " + data.count() + " rows into data table");

    }

    @After
    public void tearDown() throws Exception {

    }

    @org.junit.Test
    public void testZscore() throws Exception {
        MockScenarioFactory scenarioFactory = new MockScenarioFactory();
        ZScoreAlgorithm algo = new ZScoreAlgorithm(symbol, scenarioFactory);
        algo.zscore();
        Map<Integer, ZScoreEntry> data = Database.loadZScores(symbol);
        assertEquals(1, data.size());
        assertTrue(data.containsKey(scenarioFactory.startDate));
        ZScoreEntry entry = data.get(scenarioFactory.startDate);
        entry.sanity();
        //assertEquals(zscoresFromFile.size(), entry.zscore.size());
        for(int i = 0; i < entry.zscore.length; i++) {
            logger.info("Compare zscore "+i+": "+entry.date[i]+": "+zscoresFromFile.get(i)+"/"+entry.zscore[i]);

            BigDecimal f = new BigDecimal(zscoresFromFile.get(i));
            BigDecimal z = new BigDecimal(entry.zscore[i]);

            // have to round down to 3 places to get it working! :/
            f = f.setScale(3, BigDecimal.ROUND_DOWN);
            z = z.setScale(3, BigDecimal.ROUND_DOWN);

            assertEquals(f, z);
        }

        logger.info("*****************************************");
        // now change scenario to include more data...
        scenarioFactory.endDate = 20000417;
        algo.zscore();
        data = Database.loadZScores(symbol);
        assertEquals(1, data.size());
        assertTrue(data.containsKey(scenarioFactory.startDate));
        entry = data.get(scenarioFactory.startDate);
        entry.sanity();
        assertEquals(zscoresFromFile.size(), entry.zscore.length);
        for(int i = 0; i < entry.zscore.length; i++) {
            logger.info("Compare zscore: "+entry.date[i]+": "+zscoresFromFile.get(i)+"/"+entry.zscore[i]);

            BigDecimal f = new BigDecimal(zscoresFromFile.get(i));
            BigDecimal z = new BigDecimal(entry.zscore[i]);

            // have to round down to 3 places to get it working! :/
            f = f.setScale(3, BigDecimal.ROUND_DOWN);
            z = z.setScale(3, BigDecimal.ROUND_DOWN);

            assertEquals(f, z);
        }
    }

    @Test
    public void testInitialDuplicateCloseValuesAnomaly() throws Exception {
        double results[] = {1.5, 1.09545, 0.91287};
        Database.init("test");
        String symbol = "DupCloseValues";
        Database.getDataCollection(symbol).drop();
        Database.getZScoreCollection(symbol).drop();
        DBCollection coll = Database.getDataCollection(symbol);
        MockScenarioFactory scenarioFactory = new MockScenarioFactory();

        Database.insertData(coll, scenarioFactory.startDate, 16.12);
        Database.insertData(coll, scenarioFactory.startDate + 1, 16.12);
        Database.insertData(coll, scenarioFactory.startDate + 2, 16.12);
        Database.insertData(coll, scenarioFactory.startDate + 3, 16.37);
        Database.insertData(coll, scenarioFactory.startDate + 4, 16.37);
        Database.insertData(coll, scenarioFactory.startDate + 5, 16.37);


        ZScoreAlgorithm algo = new ZScoreAlgorithm(symbol, scenarioFactory);
        algo.zscore();
        Map<Integer, ZScoreEntry> data = Database.loadZScores(symbol);
        assertEquals(1, data.size());
        assertTrue(data.containsKey(scenarioFactory.startDate));
        ZScoreEntry entry = data.get(scenarioFactory.startDate);
        assertEquals(3, entry.zscore.length);
        for(int i = 0; i < entry.zscore.length; i++) {
            logger.info("z="+entry.zscore[i]);
            assertNotEquals(0.0, entry.zscore[i]);

            BigDecimal f = new BigDecimal(results[i]);
            BigDecimal z = new BigDecimal(entry.zscore[i]);

            // have to round down to 3 places to get it working! :/
            f = f.setScale(3, BigDecimal.ROUND_DOWN);
            z = z.setScale(3, BigDecimal.ROUND_DOWN);

            assertEquals(f, z);
        }
    }

    @Test
    public void testZScoreFind() throws Exception {

        /**
         * TODO: check find results
         *        - that exit price is correct when search finishes before or at tracking end
         *        - exit price is correct when data runs out before tracking end
         */

        final String symbol = "TestZScoreFind";
        Database.init("test");

        // how much "data" there is
        final int dataRange = 20;

        final int entryLimit = -1;
        final int exitLimit = 1;

        /*
        // the following scenario date ranges are within available data
        s1.1: start=0 size=10 zscores direct increase 0-10 (NE)
        s1.2: start=0 size=10 zscores alternate in pattern #1: -1 0 1 0 -1 0 1 0 ... (EE, end with ENE)
        s1.3: start=0 size=10 zscores alternate in pattern #2: 1 0 -1 0 1 0 -1 0 ... (EE, end with NE)
        s1.4: start=0 size=10 zscores alternate in pattern #3: 0 1 0 -1 0 1 0 -1 ... (EE, end on EE)
        s1.5: start=0 size=10 zscores alternate in pattern #4: 0 -1 0 1 0 -1 0 1 ... (EE, end on ENE)
        s1.6: start=0 size=10 zscores decrease 5-(-5) (ENE)

        // the following scenario date ranges will exceed the available data
        s1.7: start=0 size=20 zscores direct increase 0-10 (NE)
        s1.8: start=0 size=20 zscores alternate in pattern #1: -1 0 1 0 -1 0 1 0 ... (EE, end on ENE)
        s1.9: start=0 size=20 zscores alternate in pattern #2: 1 0 -1 0 1 0 -1 0 ... (EE, end on EE)
        s1.10: start=0 size=20 zscores alternate in pattern #3: 0 1 0 -1 0 1 0 -1 ... (EE, end on EE)
        s1.11: start=0 size=20 zscores alternate in pattern #4: 0 -1 0 1 0 -1 0 1 ... (EE, end on ENE)
        s1.12: start=0 size=20 zscores decrease 25-(-25) (ENE)

        pattern reference:

idx		p1		p2		p3		p4
0		-1		1		0		0
1		0		0		1		-1
2		1		-1		0		0
3		0		0		-1		1
4		-1		1		0		0
5		0		0		1		-1
6		1		-1		0		0
7		0		0		-1		1
8		-1		1		0		0
9		0		0		1		-1
10		1		-1		0		0
11		0		0		-1		1
12		-1		1		0		0
13		0		0		1		-1
14		1		-1		0		0
15		0		0		-1		1
16		-1		1		0		0
17		0		0		1		-1
18		1		-1		0		0
19		0		0		-1		1
         */

        int [] pattern1 = {-1, 0, 1, 0};
        int [] pattern2 = {1, 0, -1, 0};
        int [] pattern3 = {0, 1, 0, -1};
        int [] pattern4 = {0, -1, 0, 1};

        Scenario scenario1 = new Scenario("S1", 1, 0, 0, 10);
        Scenario scenario2 = new Scenario("S1", 2, 1, 1, 11);
        Scenario scenario3 = new Scenario("S1", 3, 2, 2, 12);
        Scenario scenario4 = new Scenario("S1", 4, 3, 3, 13);
        Scenario scenario5 = new Scenario("S1", 5, 4, 4, 14);
        Scenario scenario6 = new Scenario("S1", 6, 5, 5, 15);

        // these unrequited scenarios are 20 days long each, starting from t-4.
        Scenario scenario7 = new Scenario("S1", 7, 6, 4, 24);
        Scenario scenario8 = new Scenario("S1", 8, 7, 4, 24);
        Scenario scenario9 = new Scenario("S1", 9, 8, 5, 25);
        Scenario scenario10 = new Scenario("S1", 10, 9, 6, 26);
        Scenario scenario11 = new Scenario("S1", 11, 10, 7, 27);
        Scenario scenario12 = new Scenario("S1", 12, 11, 4, 24);

        Map<Integer, ZScoreEntry> zscores = new HashMap<Integer, ZScoreEntry>();
        ZScoreEntry list1 = new ZScoreEntry(10);
        ZScoreEntry list2 = new ZScoreEntry(10);
        ZScoreEntry list3 = new ZScoreEntry(10);
        ZScoreEntry list4 = new ZScoreEntry(10);
        ZScoreEntry list5 = new ZScoreEntry(20);
        ZScoreEntry list6 = new ZScoreEntry(20);
        ZScoreEntry list7 = new ZScoreEntry(20);
        ZScoreEntry list8 = new ZScoreEntry(20);
        zscores.put(0, list1);
        zscores.put(1, list2);
        zscores.put(2, list3);
        zscores.put(3, list4);
        zscores.put(4, list5);
        zscores.put(5, list6);
        zscores.put(6, list7);
        zscores.put(7, list8);


        // add a bunch of phony data, find needs to cross reference this to produce results
        for(int i = 0; i < dataRange; i++) {
            Database.insertData(Database.getDataCollection(symbol), i, i);
        }



        // s1.1
        for(int i = 0; i < 10; i++) {
            list1.addZScore(0, i);
        }

        // s1.2

        int s12EntryCount = 0;
        int s12ExitCount = 0;
        for(int i = 0; i < 10; i++) {
            int z = pattern1[ i % pattern1.length];
            list2.addZScore(i, z);
            if(z <= entryLimit)
                s12EntryCount ++;
            if(z >= exitLimit)
                s12ExitCount ++;
        }

        // s1.3

        // s1.4

        // s1.5

        // s1.6

        // s1.7

        // s1.8










        Database.insertZScores(symbol, zscores);
    }
}