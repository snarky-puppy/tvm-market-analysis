package com.tvminvestments.zscore.range;

import junit.framework.TestCase;

public class StartDateConstantTest extends TestCase {

    public void testCalculateBounds() throws Exception {

    }

    public void testNext() throws Exception {

    }
}