package com.tvminvestments.zscore;

import com.mongodb.DBCollection;
import com.tvminvestments.zscore.range.RangeBounds;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.number.OrderingComparison.lessThan;
import static org.junit.Assert.assertEquals;

public class DatabaseTest {

    private static final String collName = "DatabaseTest";

    @BeforeClass
    public static void init() throws UnknownHostException {
        Database.market = "test";

        // make sure we are clean
        Database.getDataCollection(collName).drop();
        Database.getZScoreCollection(collName).drop();

        DBCollection data = Database.getDataCollection(collName);
        DBCollection zscore = Database.getZScoreCollection(collName);

        Map<Integer, ZScoreEntry> entries = new HashMap<Integer, ZScoreEntry>();

        for(int dataDate = 0; dataDate < 5; dataDate++) {
            Database.insertData(data, dataDate, dataDate);
            ZScoreEntry entry = new ZScoreEntry(5);
            for(int startDate = 0; startDate < 5; startDate++) {
                entry.date[startDate] = startDate;
                entry.zscore[startDate] = dataDate;
            }
            entries.put(dataDate, entry);
        }

        assertEquals(5, entries.size());

        Database.insertZScores(collName, entries);
    }

    @AfterClass
    public static void cleanup() throws UnknownHostException {
        Database.getDataCollection(collName).drop();
        Database.getZScoreCollection(collName).drop();
    }

    @Test
    public void testFindSymbolBounds() throws Exception {
        RangeBounds bounds = Database.findDataBounds(collName);
        assertEquals(0, bounds.getMin());
        assertEquals(4, bounds.getMax());
    }

    @Test
    public void testLoadZScores() throws Exception {
        Map<Integer, ZScoreEntry> zscore = Database.loadZScores(collName);
        assertEquals(5, zscore.keySet().size());
        for(ZScoreEntry entry : zscore.values()) {
            entry.sanity();
            assertEquals(5, entry.date.length);
            // assert list is in order
            int lastEntry = -1;
            for(int date : entry.date) {
                if(lastEntry == -1) {
                    lastEntry = date;
                } else {
                    assertThat(lastEntry, is(lessThan(date)));
                }
            }
        }
    }
}